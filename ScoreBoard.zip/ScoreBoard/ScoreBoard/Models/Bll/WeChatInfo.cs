﻿namespace ScoreBoard.Models.Bll
{
    public class WeChatInfo
    {
        public string openid { get; set; }
        public string nickname { get; set; }
        public string headimgurl { get; set; }
        public int errcode { get; set; }
    }
}