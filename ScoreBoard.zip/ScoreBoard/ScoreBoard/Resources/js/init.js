$(function () {
	//placeholder兼容ie8
	$("input[placeholder]").placeholder();
	//文字超行打点
	// $('.dot').dotdotdot({
	// 	wrap: 'letter'
	// });
})