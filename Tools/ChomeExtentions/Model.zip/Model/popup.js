$(document).ready(function() {
    document.getElementsByName("TPL_username")[0].addEventListener("click", function() {
        console.log(document.getElementsByName("TPL_username")[0].value)
    })
});
$(document).ready(function() {
  document.getElementsByName("testBtn")[0].addEventListener("click", function() {
  alert(1);
  })
});


$(document).ready(function() {
  console.log(1);
});

$(document).ready(function() {
  console.log(2);
});
